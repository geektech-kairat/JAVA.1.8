package kg.geektech.les8.players;

public class Boss extends GameEntity{
    public Boss(int health, int damage) {
        super(health, damage);
    }
}
