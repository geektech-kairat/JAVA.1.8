package kg.geektech.les8.players;

public class Berserk extends Hero{
    public Berserk(int health, int damage) {
        super(health, damage, SuperAbility.SAVE_DAMAGE_AND_REVERT);
    }

    @Override
    public void applySuperPower(Boss boss, Hero[] heroes) {
//        int damageRandom = 1+(int)(Math.random()*boss.getDamage());
//        if (boss.getHealth() > 0 && getHealth() >0){
//            boss.setHealth(boss.getHealth()-damageRandom);
//            System.out.println("BERSERK отнял жизнь босса на дополнительно  : " + damageRandom);
//
//
//    }


    }
}
