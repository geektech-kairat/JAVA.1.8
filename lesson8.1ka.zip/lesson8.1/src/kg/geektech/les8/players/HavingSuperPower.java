package kg.geektech.les8.players;

public interface HavingSuperPower {
    void applySuperPower(Boss boss, Hero[] heroes);
}
