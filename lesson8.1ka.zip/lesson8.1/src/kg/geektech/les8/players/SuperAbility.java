package kg.geektech.les8.players;

public enum SuperAbility {
    HEAL,
    BOOST,
    SAVE_DAMAGE_AND_REVERT,
    CRITICAL_DAMAGE,
}