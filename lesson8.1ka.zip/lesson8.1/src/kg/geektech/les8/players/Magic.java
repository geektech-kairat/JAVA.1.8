package kg.geektech.les8.players;

import kg.geektech.les8.game.RPG_Game;

import java.util.Arrays;

import static kg.geektech.les8.game.RPG_Game.number;

public class Magic extends Hero{
    public Magic(int health, int damage) {
        super(health, damage, SuperAbility.BOOST);
    }

    @Override
    public void applySuperPower(Boss boss, Hero[] heroes) {
        for (Hero hero : heroes) {
            if (hero != this && 2 == number) {
                hero.setDamage(hero.getDamage() + RPG_Game.random);
                System.out.println();
            }


        }
        System.out.println("Magic увеличил урон герояев на : "  + RPG_Game.random);
    }
    }

