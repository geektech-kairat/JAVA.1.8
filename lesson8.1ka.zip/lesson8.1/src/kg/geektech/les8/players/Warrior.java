package kg.geektech.les8.players;

public class Warrior extends Hero{
    public Warrior(int health, int damage) {
        super(health, damage, SuperAbility.CRITICAL_DAMAGE);
    }

    @Override
    public void applySuperPower(Boss boss, Hero[] heroes) {
        int a = 2+ (int)(Math.random()*2);
        if(boss.getHealth() > 0 && getHealth()> 0){
            int b = getDamage()*a;
            boss.setHealth(boss.getHealth() - b);
            System.out.println("Warrior критует на :  " + boss.getDamage()*a);

        }

    }
}
