package kg.geektech.les8.players;

public class Hacher extends Hero{
    public Hacher(int health, int damage) {
        super(health, damage, SuperAbility.SAVE_DAMAGE_AND_REVERT);
    }

    @Override
    public void applySuperPower(Boss boss, Hero[] heroes) {
        int hackHill = 10+(int)(Math.random()*20);
        if (boss.getHealth()>0 && getHealth()>0){
            boss.setHealth(boss.getHealth()- hackHill);
        }
        for (Hero hero : heroes) {
            hero.setHealth(hero.getHealth() + hackHill);
            System.out.println("heal: " + hackHill + hero.getClass().getSimpleName());
            break;



    }


    }
}
