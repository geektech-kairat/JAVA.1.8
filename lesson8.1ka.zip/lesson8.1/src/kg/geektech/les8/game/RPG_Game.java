package kg.geektech.les8.game;

import kg.geektech.les8.players.*;

import java.util.Random;

public class RPG_Game {


    public static int number;
    public static int random;

    public static void start() {
        Boss boss = new Boss(700, 50);
        Warrior warrior = new Warrior(270, 20);
        Magic magic = new Magic(230, 15);
        Medic doctor = new Medic(220, 5, 15);
        Berserk berserk = new Berserk(260, 10);
        Medic assistant = new Medic(280, 10, 5);
        Hacher hacher = new Hacher(300,0);
        Hero[] heroes = {warrior, magic, doctor, berserk, assistant, hacher };

        printStatistics(boss, heroes);
        while (!isGameFinished(boss, heroes)) {
            round(boss, heroes);
             random = 1+(int)(Math.random()*5-1);
        }
    }

    private static void round(Boss boss, Hero[] heroes) {
        applySuperAbilities(boss, heroes);
        heroesHit(boss, heroes);
        bossHits(boss, heroes);
        printStatistics(boss, heroes);
    }

    private static void applySuperAbilities(Boss boss, Hero[] heroes){
        for (int i = 0; i <heroes.length ; i++) {
            if(heroes[i].getHealth() > 0){
            heroes[i].applySuperPower(boss, heroes);
            }
        }
    }

    private static void bossHits(Boss boss, Hero[] heroes) {
        number = (int) (Math.random() * 5);
        for (int i = 0; i < heroes.length; i++) {
            if (number == 2 ){
                System.out.println("босс бропускает один раунд ");
                break;
            }
            else if (heroes[i].getHealth() > 0) {
                heroes[i].setHealth(heroes[i].getHealth() - boss.getDamage());
            }
        }
    }

    private static void heroesHit(Boss boss, Hero[] heroes) {
        for (int i = 0; i < heroes.length; i++) {
            if (boss.getHealth() > 0 ) {
                boss.setHealth(boss.getHealth() - heroes[i].getDamage());
            }
        }
    }

    private static void printStatistics(Boss boss, Hero[] heroes) {
        System.out.println("______________");
        System.out.println("Boss health: " + boss.getHealth());
        for (int i = 0; i < heroes.length; i++) {
            System.out.println(heroes[i].getClass().getSimpleName() +
                    " health: " + heroes[i].getHealth() + " [" +
                    heroes[i].getDamage() + "]" + " ");
        }
        System.out.println("______________");
    }

    private static boolean isGameFinished(Boss boss, Hero[] heroes) {
        if (boss.getHealth() <= 0) {
            System.out.println("Heroes won!!!");
            return true;
        }

        boolean allHeroesDead = true;
        for (int i = 0; i < heroes.length; i++) {
            if (heroes[i].getHealth() > 0) {
                allHeroesDead = false;
                break;
            }
        }

        if (allHeroesDead) {
            System.out.println("Boss won!!!");
        }

        return allHeroesDead;
    }
}
